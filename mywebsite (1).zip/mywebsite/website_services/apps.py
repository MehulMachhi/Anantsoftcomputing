from django.apps import AppConfig


class WebsiteServicesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'website_services'
